import sys
import os
import json
import ssl
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

URL_CATALOGO = "https://nogueira01.github.io/telona/catalogo.json"
ICON_DEFAULT = os.path.join(ADDON_PATH, "icon.png")
FANART_DEFAULT = os.path.join(ADDON_PATH, "fanart.jpg")
ICON_FILMES = os.path.join(ADDON_PATH, "resources", "icon_filmes.png")
ICON_SERIES = os.path.join(ADDON_PATH, "resources", "icon_series.png")
CATALOGO_LOCAL = os.path.join(ADDON_PATH, "catalogo.json")


def get_url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def carregar_catalogo():
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(URL_CATALOGO, headers={"User-Agent": "Kodi-CineTelona/1.6.1"})
        with urllib.request.urlopen(req, timeout=8, context=ctx) as resp:
            dados = json.loads(resp.read().decode("utf-8"))
            if isinstance(dados, dict):
                return dados
    except Exception:
        pass
    try:
        with open(CATALOGO_LOCAL, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"filmes": [], "series": []}


def aplicar_view_painel():
    try:
        xbmc.executebuiltin("Container.SetViewMode(51)")
    except Exception:
        pass


def menu_principal():
    xbmcplugin.setPluginCategory(HANDLE, "Cine Telona")
    xbmcplugin.setContent(HANDLE, "videos")

    cat = carregar_catalogo()
    total_filmes = len(cat.get("filmes", []))
    total_series = len(cat.get("series", []))

    item_bv = xbmcgui.ListItem(label="[COLOR FF00E5FF]★ Bem-vindo ao Cine Telona ★[/COLOR]")
    item_bv.setArt({"thumb": ICON_DEFAULT, "icon": ICON_DEFAULT, "fanart": FANART_DEFAULT})
    item_bv.setInfo("video", {"title": "Bem-vindo ao Cine Telona", "plot": "Escolha Filmes ou Séries abaixo para explorar o catálogo."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="home"), listitem=item_bv, isFolder=True)

    item_f = xbmcgui.ListItem(label=f"[B][COLOR FF00E5FF]FILMES[/COLOR][/B] [COLOR FFAAAAAA]({total_filmes})[/COLOR]")
    item_f.setArt({"thumb": ICON_FILMES, "icon": ICON_FILMES, "fanart": FANART_DEFAULT})
    item_f.setInfo("video", {"title": "Filmes", "plot": "Catálogo completo de filmes."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="filmes"), listitem=item_f, isFolder=True)

    item_s = xbmcgui.ListItem(label=f"[B][COLOR FFB565FF]SÉRIES[/COLOR][/B] [COLOR FFAAAAAA]({total_series})[/COLOR]")
    item_s.setArt({"thumb": ICON_SERIES, "icon": ICON_SERIES, "fanart": FANART_DEFAULT})
    item_s.setInfo("video", {"title": "Séries", "plot": "Catálogo completo de séries."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="series"), listitem=item_s, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_filmes(filtro=""):
    xbmcplugin.setPluginCategory(HANDLE, "Filmes")
    xbmcplugin.setContent(HANDLE, "movies")

    if not filtro:
        item_busca = xbmcgui.ListItem(label="[COLOR FF00E5FF]🔍 Buscar Filme...[/COLOR]")
        item_busca.setArt({"thumb": ICON_FILMES, "icon": ICON_FILMES, "fanart": FANART_DEFAULT})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="buscar_filme"), listitem=item_busca, isFolder=True)

    cat = carregar_catalogo()
    for idx, filme in enumerate(cat.get("filmes", [])):
        titulo = filme.get("titulo", "Sem Título")
        if filtro and filtro.lower() not in titulo.lower():
            continue
        ano = filme.get("ano", "")
        sinopse = filme.get("sinopse", "")
        capa = filme.get("capa") or ICON_FILMES
        fundo = filme.get("fundo") or FANART_DEFAULT

        label = f"{titulo} ({ano})" if ano else titulo
        item = xbmcgui.ListItem(label=label)
        item.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {"title": titulo, "year": ano, "plot": sinopse, "mediatype": "movie"})

        opcoes = filme.get("opcoes", [])
        magnet_direto = filme.get("magnet", "")

        if opcoes:
            url = get_url(action="opcoes_filme", idx=idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        elif magnet_direto:
            item.setProperty("IsPlayable", "true")
            url = get_url(action="play", magnet=magnet_direto, titulo=titulo, ano=str(ano), sinopse=sinopse, capa=capa, fundo=fundo, mediatype="movie")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_view_painel()


def listar_opcoes_filme(idx):
    cat = carregar_catalogo()
    filmes = cat.get("filmes", [])
    if idx < 0 or idx >= len(filmes):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    filme = filmes[idx]
    titulo = filme.get("titulo", "Filme")
    ano = filme.get("ano", "")
    sinopse = filme.get("sinopse", "")
    capa = filme.get("capa") or ICON_FILMES
    fundo = filme.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "movies")

    for op in filme.get("opcoes", []):
        qual = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        if not magnet:
            continue
        q_low = qual.lower()
        if "4k" in q_low or "2160" in q_low:
            tag = f"[COLOR FFFFD700]★ {qual}[/COLOR]"
        elif "full" in q_low:
            tag = f"[COLOR FFB565FF]◆ {qual}[/COLOR]"
        else:
            tag = f"[COLOR FF00E5FF]● {qual}[/COLOR]"

        item = xbmcgui.ListItem(label=f"{titulo} - {tag}")
        item.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {"title": titulo, "year": ano, "plot": sinopse, "mediatype": "movie"})
        item.setProperty("IsPlayable", "true")
        url = get_url(action="play", magnet=magnet, titulo=titulo, ano=str(ano), sinopse=sinopse, capa=capa, fundo=fundo, mediatype="movie")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_series(filtro=""):
    xbmcplugin.setPluginCategory(HANDLE, "Séries")
    xbmcplugin.setContent(HANDLE, "tvshows")

    if not filtro:
        item_busca = xbmcgui.ListItem(label="[COLOR FFB565FF]🔍 Buscar Série...[/COLOR]")
        item_busca.setArt({"thumb": ICON_SERIES, "icon": ICON_SERIES, "fanart": FANART_DEFAULT})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action="buscar_serie"), listitem=item_busca, isFolder=True)

    cat = carregar_catalogo()
    for idx, serie in enumerate(cat.get("series", [])):
        titulo = serie.get("titulo", "Sem Título")
        if filtro and filtro.lower() not in titulo.lower():
            continue
        ano = serie.get("ano", "")
        sinopse = serie.get("sinopse", "")
        capa = serie.get("capa") or ICON_SERIES
        fundo = serie.get("fundo") or FANART_DEFAULT

        label = f"{titulo} ({ano})" if ano else titulo
        item = xbmcgui.ListItem(label=label)
        item.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {"title": titulo, "tvshowtitle": titulo, "year": ano, "plot": sinopse, "mediatype": "tvshow"})
        url = get_url(action="temporadas", s_idx=idx)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    aplicar_view_painel()


def listar_temporadas(s_idx):
    cat = carregar_catalogo()
    series = cat.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    titulo = serie.get("titulo", "Série")
    sinopse = serie.get("sinopse", "")
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT

    xbmcplugin.setPluginCategory(HANDLE, titulo)
    xbmcplugin.setContent(HANDLE, "seasons")

    for temp in sorted(serie.get("temporadas", {}).keys(), key=lambda x: int(x) if x.isdigit() else 0):
        item = xbmcgui.ListItem(label=f"[COLOR FF00E5FF]Temporada {temp}[/COLOR]")
        item.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {"title": f"Temporada {temp}", "tvshowtitle": titulo, "season": int(temp) if temp.isdigit() else 1, "plot": sinopse, "mediatype": "season"})
        url = get_url(action="episodios", s_idx=s_idx, temp=temp)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_episodios(s_idx, temp):
    cat = carregar_catalogo()
    series = cat.get("series", [])
    if s_idx < 0 or s_idx >= len(series):
        xbmcplugin.endOfDirectory(HANDLE)
        return

    serie = series[s_idx]
    nome_serie = serie.get("titulo", "Série")
    ano = serie.get("ano", "")
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    eps = serie.get("temporadas", {}).get(str(temp), [])

    xbmcplugin.setPluginCategory(HANDLE, f"{nome_serie} - Temporada {temp}")
    xbmcplugin.setContent(HANDLE, "episodes")

    t_num = int(temp) if str(temp).isdigit() else 1
    for e_idx, ep in enumerate(eps):
        ep_num = ep.get("episodio", e_idx + 1)
        ep_tit = ep.get("titulo", f"Episódio {ep_num}")
        ep_sin = ep.get("sinopse", serie.get("sinopse", ""))

        label = f"[COLOR FF00E5FF]{t_num:02d}x{int(ep_num):02d}[/COLOR] - {ep_tit}"
        item = xbmcgui.ListItem(label=label)
        item.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {"title": ep_tit, "tvshowtitle": nome_serie, "season": t_num, "episode": int(ep_num), "year": ano, "plot": ep_sin, "mediatype": "episode"})

        opcoes = ep.get("opcoes", [])
        magnet = ep.get("magnet", "")
        if opcoes:
            url = get_url(action="opcoes_ep", s_idx=s_idx, temp=temp, e_idx=e_idx)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=True)
        elif magnet:
            item.setProperty("IsPlayable", "true")
            url = get_url(action="play", magnet=magnet, titulo=ep_tit, tvshow=nome_serie, season=str(t_num), episode=str(ep_num), ano=str(ano), sinopse=ep_sin, capa=capa, fundo=fundo, mediatype="episode")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def listar_opcoes_ep(s_idx, temp, e_idx):
    cat = carregar_catalogo()
    serie = cat.get("series", [])[s_idx]
    ep = serie.get("temporadas", {}).get(str(temp), [])[e_idx]
    nome_serie = serie.get("titulo", "Série")
    ep_tit = ep.get("titulo", "Episódio")
    ep_num = ep.get("episodio", e_idx + 1)
    ep_sin = ep.get("sinopse", "")
    ano = serie.get("ano", "")
    capa = serie.get("capa") or ICON_SERIES
    fundo = serie.get("fundo") or FANART_DEFAULT
    t_num = int(temp) if str(temp).isdigit() else 1

    xbmcplugin.setPluginCategory(HANDLE, ep_tit)
    xbmcplugin.setContent(HANDLE, "episodes")

    for op in ep.get("opcoes", []):
        qual = op.get("qualidade", "HD")
        magnet = op.get("magnet", "")
        if not magnet:
            continue
        item = xbmcgui.ListItem(label=f"{ep_tit} - [COLOR FF00E5FF]{qual}[/COLOR]")
        item.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
        item.setInfo("video", {"title": ep_tit, "tvshowtitle": nome_serie, "season": t_num, "episode": int(ep_num), "year": ano, "plot": ep_sin, "mediatype": "episode"})
        item.setProperty("IsPlayable", "true")
        url = get_url(action="play", magnet=magnet, titulo=ep_tit, tvshow=nome_serie, season=str(t_num), episode=str(ep_num), ano=str(ano), sinopse=ep_sin, capa=capa, fundo=fundo, mediatype="episode")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def reproduzir(params):
    magnet = params.get("magnet", "")
    titulo = params.get("titulo", "Cine Telona")
    sinopse = params.get("sinopse", "")
    capa = params.get("capa", ICON_DEFAULT)
    fundo = params.get("fundo", FANART_DEFAULT)
    mediatype = params.get("mediatype", "movie")
    ano = params.get("ano", "")

    if magnet.startswith("magnet:"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok("Cine Telona", "O add-on Elementum não está instalado. Instale o Elementum pelo Repositório Telona para reproduzir torrents.")
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())
            return
        play_path = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote_plus(magnet)}"
    else:
        play_path = magnet

    info = {"title": titulo, "plot": sinopse, "mediatype": mediatype}
    if ano.isdigit():
        info["year"] = int(ano)
    if mediatype == "episode":
        info["tvshowtitle"] = params.get("tvshow", "")
        if params.get("season", "").isdigit():
            info["season"] = int(params["season"])
        if params.get("episode", "").isdigit():
            info["episode"] = int(params["episode"])

    li = xbmcgui.ListItem(path=play_path)
    li.setArt({"thumb": capa, "poster": capa, "icon": capa, "fanart": fundo})
    li.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action", "home")

    if action == "filmes":
        listar_filmes()
    elif action == "buscar_filme":
        kb = xbmc.Keyboard("", "Buscar Filme no Cine Telona")
        kb.doModal()
        if kb.isConfirmed():
            listar_filmes(kb.getText().strip())
        else:
            listar_filmes()
    elif action == "opcoes_filme":
        listar_opcoes_filme(int(params.get("idx", 0)))
    elif action == "series":
        listar_series()
    elif action == "buscar_serie":
        kb = xbmc.Keyboard("", "Buscar Série no Cine Telona")
        kb.doModal()
        if kb.isConfirmed():
            listar_series(kb.getText().strip())
        else:
            listar_series()
    elif action == "temporadas":
        listar_temporadas(int(params.get("s_idx", 0)))
    elif action == "episodios":
        listar_episodios(int(params.get("s_idx", 0)), params.get("temp", "1"))
    elif action == "opcoes_ep":
        listar_opcoes_ep(int(params.get("s_idx", 0)), params.get("temp", "1"), int(params.get("e_idx", 0)))
    elif action == "play":
        reproduzir(params)
    else:
        menu_principal()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
